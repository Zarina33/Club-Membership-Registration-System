
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Форма регистрации</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
      <style type="text/css">
            body{
            background-image: url(../../images/3d-robot-hand-background-ai-technology-side-view.jpg);
            background-size: cover;
            color:white;
            padding:10px;
            font-family: Arial,Verdana,sans-serif;
        }
        button{
            border-radius: 10px;
            color:#64645a;
        }
        a{
            font-size: 35px;
            color: white;
        }
    </style>
</head>
<body>
    <div>
    <center>             

      <br><center><a href="show.php">Show datebase</a></center>
      <br>
    
  
    
</body>
</html>
