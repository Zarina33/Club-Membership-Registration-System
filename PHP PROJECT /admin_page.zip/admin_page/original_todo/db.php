<?php 


$host_name = 'localhost';
$db_user = 'root';
$db_pass = 'root';
$db_name = 'cit_crud';

$con = mysqli_connect($host_name,$db_user,$db_pass,$db_name);
?>